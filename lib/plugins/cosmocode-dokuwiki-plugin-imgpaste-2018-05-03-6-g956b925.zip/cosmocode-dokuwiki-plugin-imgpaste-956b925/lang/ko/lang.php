<?php
/**
 * Korean language file for imgpaste plugin
 *
 * @sc yoo  <dryoo@live.com>
 */

$lang['e_nodata']         = '클립보드에 사진이 없습니다.';
$lang['js']['inprogress'] = '올리는 중입니다. 기다려주세요.';



//Setup VIM: ex: et ts=4 :
