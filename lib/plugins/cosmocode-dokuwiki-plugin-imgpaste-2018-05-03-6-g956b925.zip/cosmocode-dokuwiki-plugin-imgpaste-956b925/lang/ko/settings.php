<?php
/**
 * korean language file for imgpaste plugin
 *
 * @sc yoo  <dryoo@live.com>
 */

// keys need to match the config setting name
$lang['filename'] = '올린 파일의 이름. 대체 문자열 @USER@, @NS@, @ID@, @PAGE@, strftime을 사용할 수 있습니다. 파일확장자는 자동으로 더해집니다.';



//Setup VIM: ex: et ts=4 :
