<?php
/**
 * English language file for imgpaste plugin
 *
 * @author Andreas Gohr <gohr@cosmocode.de>
 */

$lang['e_nodata']         = 'No clipboard data received.';
$lang['js']['inprogress'] = 'Upload in progress… please wait.';



//Setup VIM: ex: et ts=4 :
