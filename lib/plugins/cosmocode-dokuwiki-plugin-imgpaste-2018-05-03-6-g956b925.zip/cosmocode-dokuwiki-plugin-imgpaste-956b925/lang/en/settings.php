<?php
/**
 * english language file for imgpaste plugin
 *
 * @author Andreas Gohr <gohr@cosmocode.de>
 */

// keys need to match the config setting name
$lang['filename'] = 'How to name pasted images. You can use the placeholders @USER@, @NS@, @ID@, @PAGE@ and strftime placeholders. The file extension is added automatically.';



//Setup VIM: ex: et ts=4 :
