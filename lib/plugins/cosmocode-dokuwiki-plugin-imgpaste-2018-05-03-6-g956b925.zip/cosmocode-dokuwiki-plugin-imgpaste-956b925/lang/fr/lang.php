<?php
/**
 * French language file for imgpaste plugin
 *
 * @author Schplurtz le Déboulonné <Schplurtz@laposte.net>
 */

$lang['e_nodata']         = 'Le presse-papier est vide.';
$lang['js']['inprogress'] = 'Envoi en cours… Veuillez patienter.';

//Setup VIM: ex: et ts=4 :
