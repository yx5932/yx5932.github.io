<?php
/**
 * French language file for imgpaste plugin
 *
 * @author Schplurtz le Déboulonné <Schplurtz@laposte.net>
 */

// keys need to match the config setting name
$lang['filename'] = 'Comment nommer les images collées. Vous pouvez utiliser les motifs @USER@, @NS@, @ID@, @PAGE@ ansi que des formats de strftime. Imgpaste ajoutera automatiquement la bonne extension au nom du fichier.';

//Setup VIM: ex: et ts=4 :
