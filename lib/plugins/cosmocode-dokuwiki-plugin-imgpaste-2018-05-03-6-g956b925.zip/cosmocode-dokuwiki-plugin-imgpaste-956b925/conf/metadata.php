<?php
/**
 * Options for the imgpaste plugin
 *
 * @author Andreas Gohr <gohr@cosmocode.de>
 */


$meta['filename'] = array('string');

