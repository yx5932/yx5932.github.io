<?php
/**
 * Default settings for the imgpaste plugin
 *
 * @author Andreas Gohr <gohr@cosmocode.de>
 */

$conf['filename']    = '@NS@:pasted:%Y%m%d-%H%M%S';
