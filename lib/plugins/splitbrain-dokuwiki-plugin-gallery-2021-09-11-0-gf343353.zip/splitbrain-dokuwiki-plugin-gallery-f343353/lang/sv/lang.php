<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Tor Härnqvist <tor@harnqvist.se>
 */
$lang['pages']                 = 'Bildsidor:';
$lang['js']['addgal']          = 'Lägg till namnrymd som bildarkiv';
