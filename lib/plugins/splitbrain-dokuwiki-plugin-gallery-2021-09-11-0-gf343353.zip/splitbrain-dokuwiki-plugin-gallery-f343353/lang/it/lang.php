<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Roberto Bellingeri <bellingeri@netguru.it>
 * @author Giovanni <giovanni.antonelli@gmail.com>
 */
$lang['pages']                 = 'Pagine Galleria';
$lang['js']['addgal']          = 'Aggiungi nome alla galleria';
$lang['nothingfound']          = 'Nessuna immagine trovata.';
