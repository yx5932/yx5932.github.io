<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Alan Davies <ben.brynsadler@gmail.com>
 */
$lang['pages']                 = 'Tudalennau Oriel:';
$lang['js']['addgal']          = 'Ychwanegu namespace fel oriel';
