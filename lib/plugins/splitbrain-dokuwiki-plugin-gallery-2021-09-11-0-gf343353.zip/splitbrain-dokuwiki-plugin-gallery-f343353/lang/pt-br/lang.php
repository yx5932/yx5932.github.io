<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Frederico Gonçalves Guimarães <frederico@teia.bio.br>
 * @author Juliano Marconi Lanigra <juliano.marconi@gmail.com>
 */
$lang['pages']                 = 'Páginas da galeria:';
$lang['js']['addgal']          = 'Adicionar domínio como galeria';
$lang['nothingfound']          = 'Não foi encontrada nenhuma imagem.';
