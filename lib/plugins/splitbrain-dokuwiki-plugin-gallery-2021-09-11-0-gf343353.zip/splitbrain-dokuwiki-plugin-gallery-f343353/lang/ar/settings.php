<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Ali Almlfy <Almlfy@hotmail.com>
 */
$lang['thumbnail_width']       = 'عرض الصورة المصغرة';
$lang['thumbnail_height']      = 'طول الصورة المصغرة ';
$lang['image_width']           = 'عرض الصورة ';
$lang['image_height']          = 'ارتفاع الصورة ';
$lang['cols']                  = 'صورة لكل صف';
$lang['sort']                  = 'كيف تريد ترتيب صورة المعرض ';
$lang['sort_o_file']           = 'ترتيب حسب اسم الملف';
$lang['sort_o_mod']            = 'ترتيب حسب تاريخ الملف';
$lang['sort_o_date']           = 'ترتيب حسب التاريخ المسجل في تفاصيل الملفات';
$lang['sort_o_title']          = 'ترتيب حسب الاسم المسجل في تفاصيل الملفات';
$lang['options']               = 'اعدادت اضافية للمعرض ';
