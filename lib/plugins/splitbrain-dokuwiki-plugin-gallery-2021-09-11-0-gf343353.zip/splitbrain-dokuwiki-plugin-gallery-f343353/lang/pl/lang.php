<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Bartek S <sadupl@gmail.com>
 */
$lang['pages']                 = 'Stron galerii:';
$lang['js']['addgal']          = 'Dodaj jako galerię';
$lang['nothingfound']          = 'Brak zdjęć.';
