<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Марко М. Костић <marko.m.kostic@gmail.com>
 */
$lang['thumbnail_width']       = 'Ширина сличице';
$lang['thumbnail_height']      = 'Висина сличице';
$lang['image_width']           = 'Ширина слике';
$lang['image_height']          = 'Висина слике';
$lang['cols']                  = 'Слика по реду';
$lang['sort']                  = 'Како треба ређати слике у галерији';
$lang['sort_o_file']           = 'ређај по имену датотеке';
$lang['sort_o_mod']            = 'ређају по датуму настанка';
$lang['sort_o_date']           = 'ређај по EXIF датуму';
$lang['sort_o_title']          = 'ређај по EXIF наслову';
$lang['options']               = 'Додатне подразумеване опције галерије';
