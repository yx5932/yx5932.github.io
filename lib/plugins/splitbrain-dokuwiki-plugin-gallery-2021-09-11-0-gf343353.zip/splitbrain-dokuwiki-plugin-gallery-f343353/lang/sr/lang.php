<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Марко М. Костић <marko.m.kostic@gmail.com>
 */
$lang['pages']                 = 'Странице галерије:';
$lang['js']['addgal']          = 'Додај именски простор као галерију';
