<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Thien Hau <thienhausoftware@gmail.com>
 */
$lang['thumbnail_width']       = 'Chiều rộng hình ảnh thu nhỏ';
$lang['thumbnail_height']      = 'Chiều cao hình ảnh thu nhỏ';
$lang['image_width']           = 'Chiều rộng hình ảnh';
$lang['image_height']          = 'Chiều cao hình ảnh';
$lang['cols']                  = 'Hình ảnh mỗi hàng';
$lang['sort']                  = 'Cách sắp xếp hình ảnh thư viện';
$lang['sort_o_file']           = 'sắp xếp theo tên tập tin';
$lang['sort_o_mod']            = 'sắp xếp theo ngày';
$lang['sort_o_date']           = 'sắp xếp theo ngày EXIF';
$lang['sort_o_title']          = 'sắp xếp theo tiêu đề EXIF';
$lang['options']               = 'Tùy chọn thư viện mặc định bổ sung';
