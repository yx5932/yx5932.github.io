<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Thien Hau <thienhausoftware@gmail.com>
 */
$lang['pages']                 = 'Trang thư viện';
$lang['js']['addgal']          = 'Thêm không gian tên làm thư viện';
$lang['nothingfound']          = 'Không tìm thấy hình ảnh.';
