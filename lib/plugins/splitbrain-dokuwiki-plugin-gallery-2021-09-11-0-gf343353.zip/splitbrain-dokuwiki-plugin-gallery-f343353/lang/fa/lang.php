<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Nima Hamidian <nima.hamidian@gmail.com>
 * @author sam01 <m.sajad079@gmail.com>
 */
$lang['pages']                 = 'صفحه‌های گالری:';
$lang['js']['addgal']          = 'اضافه کردن فضای نام به‌عنوان گالری';
$lang['nothingfound']          = 'تصویری یافت نشد.';
