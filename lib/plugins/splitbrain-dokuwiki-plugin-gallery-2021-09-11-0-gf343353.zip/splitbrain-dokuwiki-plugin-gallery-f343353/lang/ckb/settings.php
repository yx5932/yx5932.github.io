<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author qezwan <qezwan@gmail.com>
 */
$lang['thumbnail_width']       = 'پانی وێنەی بچووک';
$lang['thumbnail_height']      = 'بەرزی وێنەی وێنۆچکە';
$lang['image_width']           = 'پانی وێنە';
$lang['image_height']          = 'بەرزی وێنە';
$lang['cols']                  = 'وێنەکان بۆ هەر ڕیزێک';
$lang['sort']                  = 'چۆن وێنە گەلەرییەکان پۆلێن بکەیت';
$lang['sort_o_file']           = 'پۆلێنکردن بەپێی ناوی فایل';
$lang['sort_o_mod']            = 'پۆلێنکردن بەپێی بەرواری فایل';
$lang['sort_o_date']           = 'پۆلێنکردن بەپێی بەرواری EXIF';
$lang['sort_o_title']          = 'پۆلێن کردن بە ناونیشانی EXIF';
$lang['options']               = 'هەڵبژاردنەکانی پێش گریمانەی گالەری زیاتر';
