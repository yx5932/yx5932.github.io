<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author qezwan <qezwan@gmail.com>
 */
$lang['pages']                 = 'گەلەری لاپەڕەکان:';
$lang['js']['addgal']          = 'زیادکردنی بۆشایی ناو وەک گالەری';
$lang['nothingfound']          = 'هیچ وێنەیەک نەدۆزرایەوە.';
