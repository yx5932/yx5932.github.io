<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Zigor Astarbe <astarbe@gmail.com>
 */
$lang['image_width']           = 'Irudi zabalera';
$lang['image_height']          = 'Irudi altuera';
