<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Zigor Astarbe <astarbe@gmail.com>
 */
$lang['pages']                 = 'Galeria Orriak:';
$lang['nothingfound']          = 'Irudirik ez aurkituak.';
