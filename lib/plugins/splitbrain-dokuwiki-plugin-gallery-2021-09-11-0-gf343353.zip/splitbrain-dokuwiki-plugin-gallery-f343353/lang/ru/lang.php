<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author android405 <android40561@ya.ru>
 * @author Aleksandr Selivanov <alexgearbox@yandex.ru>
 */
$lang['pages']                 = 'Страницы галереи:';
$lang['js']['addgal']          = 'Добавить пространство имён как галерею';
$lang['nothingfound']          = 'Изображения не найдены';
