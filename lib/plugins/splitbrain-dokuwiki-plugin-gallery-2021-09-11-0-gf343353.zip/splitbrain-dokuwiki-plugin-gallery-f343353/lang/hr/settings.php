<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Davor Turkalj <turki.bsc@gmail.com>
 */
$lang['thumbnail_width']       = 'Širina slikovnih minijatura';
$lang['thumbnail_height']      = 'Visina slikovnih minijatura';
$lang['image_width']           = 'Širina slike';
$lang['image_height']          = 'Visina slike';
$lang['cols']                  = 'Slika u retku';
$lang['sort']                  = 'Kako poredati slike u galeriji';
$lang['sort_o_file']           = 'poredaj po imenu';
$lang['sort_o_mod']            = 'poredaj po datumu datoteke';
$lang['sort_o_date']           = 'poredaj po EXIF datumu';
$lang['sort_o_title']          = 'poredaj po EXIF naslovu';
$lang['options']               = 'Dodatne podrazumijevane opcije galerije';
