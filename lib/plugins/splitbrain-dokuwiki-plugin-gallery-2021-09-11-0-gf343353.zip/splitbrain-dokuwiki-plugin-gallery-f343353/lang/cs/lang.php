<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Petr Kajzar <petr.kajzar@lf1.cuni.cz>
 * @author Jaroslav Lichtblau <jlichtblau@seznam.cz>
 */
$lang['pages']                 = 'Stránky galerie:';
$lang['js']['addgal']          = 'Přidat jmenný prostor jako galerii';
$lang['nothingfound']          = 'Nenalezeny žádné obrázky.';
