<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author En Matt <heartattack@free.fr>
 */
$lang['thumbnail_width']       = 'Largor de las vinhetas';
$lang['thumbnail_height']      = 'Nautor de las vinhetas';
$lang['image_width']           = 'Largor imatge';
$lang['image_height']          = 'Nautor imatge';
$lang['cols']                  = 'Imatges per linha';
$lang['sort']                  = 'Biais de triar los imatges de la galariá';
$lang['sort_o_file']           = 'triar per nom fichièr';
$lang['sort_o_mod']            = 'triar per data fichièr';
$lang['sort_o_date']           = 'triar per data EXIF';
$lang['sort_o_title']          = 'triar per títol EXIF';
$lang['options']               = 'Opcion de la galariá';
