<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author En Matt <heartattack@free.fr>
 */
$lang['pages']                 = 'Pagina galariá :';
$lang['js']['addgal']          = 'Ajustar los noms d\'espaci coma galariá';
$lang['nothingfound']          = 'Cap d\'imatge pas trobat.';
