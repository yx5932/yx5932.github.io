<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Abel Rico <aricoripoll@iesesteveterradas.cat>
 */
$lang['pages']                 = 'Pàgines de la galeria';
$lang['js']['addgal']          = 'Afegeix un espai com a galeria';
