<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Shiliew <siskyblue@hotmail.com>
 * @author ilker Rifat Kapaç <irifat@gmail.com>
 */
$lang['pages']                 = 'Sergi Sayfaları';
$lang['js']['addgal']          = 'İsimalanını sergi olarak ekle';
