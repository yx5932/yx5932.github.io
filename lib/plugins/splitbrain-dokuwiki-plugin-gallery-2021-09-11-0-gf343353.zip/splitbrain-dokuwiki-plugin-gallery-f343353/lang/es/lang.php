<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Yllelder <yllelder@gmail.com>
 * @author Joel Cantoral <cantoral.joel@gmail.com>
 * @author Domingo Redal <docxml@gmail.com>
 */
$lang['pages']                 = 'Páginas de la galería:';
$lang['js']['addgal']          = 'Añadir espacio de nombres como galería';
$lang['nothingfound']          = 'No se han encontrado imágenes.';
