<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Katerina Katapodi <extragold1234@hotmail.com>
 */
$lang['thumbnail_width']       = 'Πλάτος εικόνας thumbnail ';
$lang['thumbnail_height']      = 'Ύψος εικόνας Thumbnail ';
$lang['image_width']           = 'Πλάτος εικόνας';
$lang['image_height']          = 'Ύψος εικόνας';
$lang['cols']                  = 'Εικόνες ανά σειρά';
$lang['sort']                  = 'Πώς να επιλέξεις τις εικόνες γαλαρίας ';
$lang['sort_o_file']           = 'επιλέχθηκε από το όνομα φακέλλου';
$lang['sort_o_mod']            = 'επιλογή φακέλλου καθ\'ημερομηνία';
$lang['sort_o_date']           = 'επιλογή κατά ημερομηνία EXIF';
$lang['sort_o_title']          = 'επιλογή κατά τίτλο EXIF ';
$lang['options']               = 'Επιπλέον επιλογές από γκαλερί';
