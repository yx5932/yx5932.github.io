<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Katerina Katapodi <extragold1234@hotmail.com>
 */
$lang['pages']                 = 'Σελίδες Gallery';
$lang['js']['addgal']          = 'Προσθέσετε χώρο για όνομα ως γκαλερί.';
$lang['nothingfound']          = 'Δεν βρέθηκαν εικόνες.';
