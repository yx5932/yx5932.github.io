<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Felix Müller-Donath <j.felix@mueller-donath.de>
 */
$lang['pages']                 = 'Galerie-Seiten:';
$lang['js']['addgal']          = 'Namensraum als Galerie hinzufügen';
